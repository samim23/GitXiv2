(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var juice;

(function(){

////////////////////////////////////////////////////////////////////////////
//                                                                        //
// packages/sacha_juice/packages/sacha_juice.js                           //
//                                                                        //
////////////////////////////////////////////////////////////////////////////
                                                                          //
(function () {                                                            // 1
                                                                          // 2
///////////////////////////////////////////////////////////////////////   // 3
//                                                                   //   // 4
// packages/sacha:juice/lib/juice.js                                 //   // 5
//                                                                   //   // 6
///////////////////////////////////////////////////////////////////////   // 7
                                                                     //   // 8
juice = Npm.require('juice');                                        // 1
///////////////////////////////////////////////////////////////////////   // 10
                                                                          // 11
}).call(this);                                                            // 12
                                                                          // 13
////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['sacha:juice'] = {
  juice: juice
};

})();

//# sourceMappingURL=sacha_juice.js.map
