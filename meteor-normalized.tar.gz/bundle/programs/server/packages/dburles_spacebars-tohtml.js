(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Spacebars = Package.spacebars.Spacebars;
var SpacebarsCompiler = Package['spacebars-compiler'].SpacebarsCompiler;
var Blaze = Package.blaze.Blaze;
var UI = Package.blaze.UI;
var Handlebars = Package.blaze.Handlebars;
var HTML = Package.htmljs.HTML;

(function(){

//////////////////////////////////////////////////////////////////////////
//                                                                      //
// packages/dburles_spacebars-tohtml/spacebars-tohtml.js                //
//                                                                      //
//////////////////////////////////////////////////////////////////////////
                                                                        //
Spacebars.toHTML = function(data, template) {                           // 1
  var compiled = SpacebarsCompiler.compile(template, { isBody: true });
  var fn = eval(compiled);                                              // 3
  return Blaze.toHTML(Blaze.With(data, fn));                            // 4
};                                                                      // 5
//////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['dburles:spacebars-tohtml'] = {};

})();

//# sourceMappingURL=dburles_spacebars-tohtml.js.map
