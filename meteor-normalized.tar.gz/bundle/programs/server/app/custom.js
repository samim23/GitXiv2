(function(){

/////////////////////////////////////////////////////////////////////////
//                                                                     //
// custom.js                                                           //
//                                                                     //
/////////////////////////////////////////////////////////////////////////
                                                                       //
// if(Meteor.startup){                                                 //
// 	Avatar.options = {                                                 //
// 		gravatarDefault: 'initials' // default is 404                     //
// 	};                                                                 //
// }                                                                   //
                                                                       //
if (Meteor.isClient) {                                                 // 7
  Template.registerHelper("isEmpty", function (object) {               // 8
    if (object === undefined) {                                        // 9
      return false;                                                    // 9
    }                                                                  //
    return true;                                                       // 10
  });                                                                  //
  Template.post_title.helpers({                                        // 12
    custom_title: function () {                                        // 13
      return this.title;                                               // 14
    },                                                                 //
    custom_link: function () {                                         // 16
      return '/posts/' + this._id + '/' + this.slug;                   // 17
    }                                                                  //
  });                                                                  //
}                                                                      //
                                                                       //
// Github API                                                          //
// if(Meteor.isServer){                                                //
// 	if(Meteor.startup){                                                //
// 		console.log("Github Start: ");                                    //
// 		var github = new GitHub({                                         //
// 		    version: "3.0.0", // required                                 //
// 		    timeout: 5000     // optional                                 //
// 		});                                                               //
// 		Meteor.methods({                                                  //
// 			'repocontent':function(uname,repoName){                          //
// 				var ret = "loading";                                            //
// 				github.repos.get({                                              //
// 				    user: uname,                                                //
// 				    repo: repoName                                              //
// 				}, function(err, res) {                                         //
// 					ret = res;                                                     //
// 					//JSON.stringify(res)                                          //
// 				    //console.log(ret);                                         //
// 				});                                                             //
// 				return ret;                                                     //
// 	    	}                                                             //
// 	    });                                                            //
// 	}                                                                  //
// }                                                                   //
// else{                                                               //
// 	Meteor.setTimeout(function(){                                      //
// 		Meteor.call("repocontent","samim23","DeepDreamAnim",function(e,r){
//       		console.log(r);                                             //
//     	});                                                            //
// 	},1000);                                                           //
// }                                                                   //
                                                                       //
// Posts.removeField("services_headline")                              //
                                                                       //
Posts.addField({                                                       // 56
  fieldName: 'body',                                                   // 57
  fieldSchema: {                                                       // 58
    type: String,                                                      // 59
    label: "",                                                         // 60
    defaultValue: "...",                                               // 61
    optional: true,                                                    // 62
    'public': true,                                                    // 63
    autoform: {                                                        // 64
      omit: true                                                       // 65
    }                                                                  //
  }                                                                    //
});                                                                    //
Posts.addField({                                                       // 69
  fieldName: 'thumbnailUrl',                                           // 70
  fieldSchema: {                                                       // 71
    type: String,                                                      // 72
    label: "Thumbnail URL",                                            // 73
    optional: true,                                                    // 74
    'public': true,                                                    // 75
    editableBy: ["member", "admin"],                                   // 76
    autoform: {                                                        // 77
      omit: true                                                       // 78
    }                                                                  //
  }                                                                    //
});                                                                    //
Posts.addField({                                                       // 82
  fieldName: 'url',                                                    // 83
  fieldSchema: {                                                       // 84
    type: String,                                                      // 85
    label: "URL",                                                      // 86
    optional: true,                                                    // 87
    'public': true,                                                    // 88
    editableBy: ["member", "admin"],                                   // 89
    autoform: {                                                        // 90
      omit: true                                                       // 91
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 97
  fieldName: 'title',                                                  // 98
  fieldSchema: {                                                       // 99
    type: String,                                                      // 100
    label: "Title (< 100char)",                                        // 101
    optional: true,                                                    // 102
    'public': true,                                                    // 103
    max: 100,                                                          // 104
    editableBy: ["member", "admin"],                                   // 105
    autoform: {                                                        // 106
      omit: false                                                      // 107
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 112
  fieldName: 'services_headline',                                      // 113
  fieldSchema: {                                                       // 114
    type: String,                                                      // 115
    label: "Headline (< 100char)",                                     // 116
    optional: true,                                                    // 117
    'public': true,                                                    // 118
    max: 100,                                                          // 119
    editableBy: ["member", "admin"],                                   // 120
    autoform: {                                                        // 121
      omit: false                                                      // 122
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 127
  fieldName: 'services_abstract',                                      // 128
  fieldSchema: {                                                       // 129
    type: String,                                                      // 130
    label: "Abstract (< 500char)",                                     // 131
    max: 500,                                                          // 132
    optional: true,                                                    // 133
    'public': true,                                                    // 134
    editableBy: ["member", "admin"],                                   // 135
    autoform: {                                                        // 136
      omit: false,                                                     // 137
      rows: 2                                                          // 138
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 143
  fieldName: 'services_thumbnail',                                     // 144
  fieldSchema: {                                                       // 145
    type: String,                                                      // 146
    label: "Thumbnail URL",                                            // 147
    optional: true,                                                    // 148
    'public': true,                                                    // 149
    editableBy: ["member", "admin"],                                   // 150
    autoform: {                                                        // 151
      omit: false                                                      // 152
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 157
  fieldName: 'services_github_date_created',                           // 158
  fieldSchema: {                                                       // 159
    type: Date,                                                        // 160
    label: "Github: Date",                                             // 161
    optional: true,                                                    // 162
    'public': true,                                                    // 163
    editableBy: ["member", "admin"],                                   // 164
    autoform: {                                                        // 165
      omit: true                                                       // 166
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 171
  fieldName: 'services_github_url',                                    // 172
  fieldSchema: {                                                       // 173
    type: String,                                                      // 174
    label: "GitHub: URL",                                              // 175
    optional: true,                                                    // 176
    'public': true,                                                    // 177
    editableBy: ["member", "admin"],                                   // 178
    autoform: {                                                        // 179
      omit: false                                                      // 180
    }                                                                  //
  }                                                                    //
});                                                                    //
Posts.addField({                                                       // 184
  fieldName: 'services_github_abstract',                               // 185
  fieldSchema: {                                                       // 186
    type: String,                                                      // 187
    label: "GitHub: Abstract",                                         // 188
    optional: true,                                                    // 189
    'public': true,                                                    // 190
    editableBy: ["member", "admin"],                                   // 191
    autoform: {                                                        // 192
      omit: false,                                                     // 193
      rows: 2                                                          // 194
    }                                                                  //
  }                                                                    //
});                                                                    //
Posts.addField({                                                       // 198
  fieldName: 'services_github_dependencies',                           // 199
  fieldSchema: {                                                       // 200
    type: [String],                                                    // 201
    label: "GitHub: Dependencies",                                     // 202
    optional: true,                                                    // 203
    'public': true,                                                    // 204
    editableBy: ["member", "admin"],                                   // 205
    autoform: {                                                        // 206
      omit: false                                                      // 207
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 212
  fieldName: 'services_arxiv_url',                                     // 213
  fieldSchema: {                                                       // 214
    type: String,                                                      // 215
    label: "Arxiv: URL",                                               // 216
    optional: true,                                                    // 217
    'public': true,                                                    // 218
    editableBy: ["member", "admin"],                                   // 219
    autoform: {                                                        // 220
      omit: false                                                      // 221
    }                                                                  //
  }                                                                    //
});                                                                    //
Posts.addField({                                                       // 225
  fieldName: 'services_arxiv_abstract',                                // 226
  fieldSchema: {                                                       // 227
    type: String,                                                      // 228
    label: "Arxiv: Abstract",                                          // 229
    optional: true,                                                    // 230
    'public': true,                                                    // 231
    editableBy: ["member", "admin"],                                   // 232
    autoform: {                                                        // 233
      omit: false,                                                     // 234
      rows: 2                                                          // 235
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 240
  fieldName: 'services_arxiv_date',                                    // 241
  fieldSchema: {                                                       // 242
    type: Date,                                                        // 243
    label: "Arxiv: Date",                                              // 244
    optional: true,                                                    // 245
    'public': true,                                                    // 246
    editableBy: ["member", "admin"],                                   // 247
    autoform: {                                                        // 248
      omit: true                                                       // 249
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 254
  fieldName: 'services_arxiv_authors',                                 // 255
  fieldSchema: {                                                       // 256
    type: [String],                                                    // 257
    label: "Arxiv: Authors",                                           // 258
    optional: true,                                                    // 259
    'public': true,                                                    // 260
    max: 1000,                                                         // 261
    editableBy: ["member", "admin"],                                   // 262
    autoform: {                                                        // 263
      omit: true                                                       // 264
    }                                                                  //
  }                                                                    //
});                                                                    //
                                                                       //
Posts.addField({                                                       // 269
  fieldName: 'services_links',                                         // 270
  fieldSchema: {                                                       // 271
    type: [String],                                                    // 272
    label: "Links",                                                    // 273
    optional: true,                                                    // 274
    'public': true,                                                    // 275
    editableBy: ["member", "admin"],                                   // 276
    autoform: {                                                        // 277
      omit: false                                                      // 278
    }                                                                  //
  }                                                                    //
});                                                                    //
/////////////////////////////////////////////////////////////////////////

}).call(this);

//# sourceMappingURL=custom.js.map
